#include "parsing.h"
#include "../libft/libft.h"

char *expand_pid(char *token, int i)
{
	char *new_str = NULL;
	char *temp;
	pid_t pid;
	char *pid_str;
	int dollar_count = 0;

	pid = getpid();
	pid_str = ft_itoa(pid);

    while (token[i + dollar_count] == '$')
        dollar_count++;

    if (dollar_count > 1)
    {
        char *sub_str = ft_substr(token, 0, i);
        new_str = ft_strjoin(sub_str, pid_str);
        free(sub_str);

        while (dollar_count > 2)
        {
            temp = ft_strjoin(new_str, pid_str);
            free(new_str);
            new_str = temp;
            dollar_count -= 2;
        }

        temp = ft_strjoin(new_str, &token[i + dollar_count]);
        free(new_str);
        free(token);
        token = temp;
    }

    free(pid_str);
    return token;
}

char *expand_exit_status(char *token, int i, int last_exit_status)
{
    char *new_str;
    char *status_str;
    char *temp;

    status_str = ft_itoa(last_exit_status);

    char *sub_str = ft_substr(token, 0, i);
    new_str = ft_strjoin(sub_str, status_str);
    free(sub_str);

    temp = ft_strjoin(new_str, &token[i + 2]);
    free(new_str);
    free(status_str);
    free(token);
    token = temp;

    return token;
}

char *handle_literal_dollar(char *token, int i)
{
    char *new_str;
    char *sub_str;

    sub_str = ft_substr(token, 0, i);
    new_str = ft_strjoin(sub_str, &token[i + 1]);
    free(sub_str);
    free(token);
    return new_str;
}

char *handle_invalid_variable(char *token, int *i)
{
    (*i)++;

    while (token[*i] && (ft_isdigit(token[*i]) || (!ft_isalnum(token[*i]) && token[*i] != '_')))
        (*i)++;

    return token;
}

char *expand_env_var(char *token, t_env *env_list, int last_exit_status)
{
    int i = 0;
    int j;
    char *new_str = NULL;
    char *var_name;
    char *var_value;
    char *temp;

    while (token[i])
    {
        if (token[i] == '\\' && token[i + 1] == '$')
        {
            token = handle_literal_dollar(token, i);
            i++;
        }
        else if (token[i] == '$')
        {
            if (token[i + 1] == '$')
            {
                token = expand_pid(token, i);
                i += ft_strlen(ft_itoa(getpid())) - 1;
            }
            else if (token[i + 1] == '?')
            {
                token = expand_exit_status(token, i, last_exit_status);
                i += ft_strlen(ft_itoa(last_exit_status)) - 1;
            }
            else if (ft_isdigit(token[i + 1]) || (!ft_isalnum(token[i + 1]) && token[i + 1] != '_'))
            {
                token = handle_invalid_variable(token, &i);
            }
            else
            {
                j = i + 1;
                while (ft_isalnum(token[j]) || token[j] == '_')
                    j++;

                var_name = trim_str(token, i + 1, j);
                var_value = get_env_clone(var_name, env_list);
                free(var_name);

                if (var_value)
                {
                    char *sub_str = ft_substr(token, 0, i);
                    new_str = ft_strjoin(sub_str, var_value);
                    free(sub_str);

                    temp = ft_strjoin(new_str, &token[j]);
                    free(new_str);
                    free(token);
                    token = temp;
                    i += ft_strlen(var_value) - 1;
                }
                else
                    i = j;
            }
        }
        else
        {
            i++;
        }
    }
    return token;
}

#include <stdio.h>
#include <stdlib.h>
#include <readline/readline.h>
#include <readline/history.h>
#include "parsing.h"
#include "../libft/libft.h"

// A mock structure for the environment list (replace this with your actual structure)
typedef struct s_env {
    char *key;
    char *value;
    struct s_env *next;
} t_env;

// A mock function to retrieve an environment variable from the list (replace this with your actual function)
char *get_env_clone(char *var_name, t_env *env_list)
{
    t_env *current = env_list;

    while (current)
    {
        if (strcmp(current->key, var_name) == 0)
            return current->value;
        current = current->next;
    }
    return NULL; // Return NULL if the variable is not found
}

// A helper function to create environment variable nodes (for testing purposes)
t_env *create_env(char *key, char *value)
{
    t_env *env = malloc(sizeof(t_env));
    env->key = key;
    env->value = value;
    env->next = NULL;
    return env;
}

// Mock environment setup for testing
t_env *setup_mock_env()
{
    t_env *env_list = create_env("USER", "test_user");
    env_list->next = create_env("HOME", "/home/test_user");
    env_list->next->next = create_env("SHELL", "/bin/minishell");
    return env_list;
}

int main(void)
{
    char *input;
    t_env *env_list = setup_mock_env(); // Initialize mock environment
    int last_exit_status = 127; // Simulate a last exit status

    while (1)
    {
        input = readline("minishell> "); // Read input from user
        if (!input)
            break;

        add_history(input); // Add input to history

        char *expanded_input = expand_env_var(input, env_list, last_exit_status); // Expand variables
        printf("Expanded: %s\n", expanded_input); // Print the result

        free(expanded_input); // Free the expanded string
        free(input); // Free the original input
    }

    return 0;
}
